#include "swap.h"

#include <vector>

void init(int N, int M,
          std::vector<int> U, std::vector<int> V, std::vector<int> W) {

}

int getMinimumFuelCapacity(int X, int Y) {
  return 0;
}
