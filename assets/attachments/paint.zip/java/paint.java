public class paint {
  public int minimumInstructions(
      int N, int M, int K, int[] C, int[] A, int[][] B) {
    return 0;
  }
}
