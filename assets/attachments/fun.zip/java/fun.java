public class fun {
  public int[] createFunTour(int N, int Q) {
    int H = grader.hoursRequired(0, N - 1);
    int A = grader.attractionsBehind(0, N - 1);
    return new int[N];
  }
}
